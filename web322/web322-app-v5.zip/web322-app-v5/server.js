/************************************************************************
*********
*  WEB
3
22 
–
Assignment
02
*  I declare t
hat this assignment is my own work in accordance with Se
neca  Academic Policy.  No part 
*  of this 
assignment has been copied manually or electronically from any other s
ource 
*  (including 3rd party web sites) or 
distributed to other students.
* 
*  Name:
_______Kevin Feanny_______________ Student ID: _______045050036_______ Date: ___28th mar 2018____________
*
*  Online (Heroku) Link: __ https://mighty-waters-69448.herokuapp.com_____________________________________________________
*
********************************************************************************/ 

var express = require("express");
var app = express();
var path = require("path");
const multer = require("multer");
var fs = require("fs");
const bodyParser = require('body-parser');
var data_service = require("./data-service.js");
const exphbs = require('express-handlebars');

var HTTP_PORT = process.env.PORT || 8080;

function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);

}
app.use(bodyParser.urlencoded({ extended: true }));
const storage = multer.diskStorage({
    destination: "./public/images/uploaded",
    filename: function (req, file, cb) {
      // we write the filename as the current date down to the millisecond
      // in a large web service this would possibly cause a problem if two people
      // uploaded an image at the exact same time. A better way would be to use GUID's for filenames.
      // this is a simple example.
      cb(null, Date.now() + path.extname(file.originalname));
    }
  });
  
  // tell multer to use the diskStorage function for naming files instead of the default.
  const upload = multer({ storage: storage });
app.use(express.static('public'));
app.use(function(req,res,next){
    let route = req.baseUrl + req.path;
    app.locals.activeRoute = (route == "/") ? "/" : route.replace(/\/$/, "");
    next();
    });
app.engine(".hbs", exphbs({
    extname: ".hbs",
    defaultLayout: 'main',
    helpers: {
        navLink: function(url, options){
            return '<li' + 
            ((url == app.locals.activeRoute) ? ' class="active" ' : '') + 
            '><a href="' + url + '">' + options.fn(this) + '</a></li>';
            },
            equal: function (lvalue, rvalue, options) {
                if (arguments.length < 3)
                throw new Error("Handlebars Helper equal needs 2 parameters");
                if (lvalue != rvalue) {
                return options.inv
                erse(this);
                } else {
                return options.fn(this);
                }
                }
        
    }
}));
app.set("view engine", ".hbs");



app.get("/", (req, res) => {
    res.render("home");
});

app.get("/about", function(req, res) {
    res.render("about");
});

app.get("/employees", (req, res) => {
    if (req.query.status) {
        data_service.getEmployeesByStatus(req.query.status).then((data) => {
           if( data.length > 0){
            res.render("employees", { data: data, title: "Employees" });}
            else{
                res.render("employees",{ message: "no results" });
            }
        }).catch((err) => {
            res.render("employees", { data: {}, title: "Employees" });
        });
    } else if (req.query.department) {
        data_service.getEmployeesByDepartment(req.query.department).then((data) => {
            if( data.length > 0){
                res.render("employees", { data: data, title: "Employees" });}
                else{
                    res.render("employees",{ message: "no results" });
                }
        }).catch((err) => {
            res.render("employees", { data: {}, title: "Employees" });
        });
    } else if (req.query.manager) {
        data_service.getEmployeesByManager(req.query.manager).then((data) => {
            if( data.length > 0){
                res.render("employees", { data: data, title: "Employees" });}
                else{
                    res.render("employees",{ message: "no results" });
                }
        }).catch((err) => {
            res.render("employees", { data: {}, title: "Employees" });
        });
    } else {
        data_service.getAllEmployees().then((data) => {
            if( data.length > 0){
                res.render("employees", { data: data, title: "Employees" });}
                else{
                    res.render("employees",{ message: "no results" });
                }
        }).catch((err) => {
            res.render("employees", { data: {}, title: "Employees" });
        });
    }
});

app.get("/employees/:empNum", (req, res) => {
    let viewData = {};
    data_service.getEmployeeByNum(req.params.empNum).then((data) => {
        viewData.data = data; //store employee data in the "viewData" object as "data"
    }).catch(() => {
        viewData.data = null; // set employee to null if there was an error
    }).then(data_service.getDepartments).then((data) => {
        viewData.departments = data; // store department data in the "viewData" object as "departments"
                                     // loop through viewData.departments and once we have found the departmentId that matches
                                     // the employee's "department" value, add a "selected" property to the matching
                                     // viewData.departments object
        for (let i = 0; i < viewData.departments.length; i++) {
            if (viewData.departments[i].departmentId == viewData.data[0].department) {
                viewData.departments[i].selected = true;
            }
        }
        // if not add department set Selected to false and promto a message to user, message like "Please Choose Department" in html.
        if (viewData.departments[viewData.departments.length-1].departmentId != viewData.data[0].department) {
            viewData.departments.Selected = false;
        }
    }).catch(() => {
        viewData.departments = []; // set departments to empty if there was an error
    }).then(() => {
        if (viewData.data == null){ // if no employee - return an error
            res.status(404).send("Employee Not Found!!!");
        } else {
            res.render("employee", { viewData: viewData }); // render the "employee" view
        }
    });
});


app.get("/departments", function(req, res) {
    data_service.getDepartments().then(function(data) {
        //if(data.length > 0){
            if( data.length > 0){
                res.render("departmentlist", { data: data, title: "Departments" });}
                else{
                    res.render("departmentlist",{ message: "no results" });
                }
        }).catch((err) => {
            res.render("departmentlist", { data: {}, title: "Departments" });
        });
});


app.get("/images/add", function(req, res){
    res.render("addImage");
});
app.post("/images/add", upload.single("imageFile"), function(req, res) {
    if (req.file) {
        console.dir(req.file);
        return res.end('Thank you for the file');
      }
  }); 
  app.get("/Images", function(req, res){
    var path = __dirname + "/public/images/uploaded";
 
    fs.readdir(path, function(err, items) {
        res.render('images', {
            data: items
        });
     
      
    });

  });
  app.get("/Emp/add", (req, res) => {
    
    res.render('addEmployee');
;
});
  app.post("/employees/add", (req, res) => {
    if (req.body) {
        console.dir(req.body);
        data_service.addEmployee(req.body).then((data) => {
        res.redirect("/employees");
    }).catch((err) => {
        console.log(err);
    });
}
});


app.post("/employees/update", (req, res) => {
    res.redirect("/employees");
});

app.post("/employee/update", (req, res) => {
    data_service.updateEmployee(req.body).then((data) => {
        res.redirect("/employees");
    }).catch((err) => {
        console.log(err);
    });
});
app.get("/Dep/add", (req, res) => {
    
    res.render('addDepartment');
;
});
app.post("/departments/add", (req, res) => {
    if (req.body) {
        console.dir(req.body);
        data_service.addDepartment(req.body).then((data) => {
        res.redirect("/departments");
    }).catch((err) => {
        console.log(err);
    });
}
});

app.get("/department/:departmentId", (req, res) => {
    data_service.getDepartmentById(req.params.departmentId).then((data) => {
        res.render("department", {
           data: data
        });
    }).catch((err) => {
        res.status(404).send("Department Not Found");
    });
});

app.post("/department/update", (req,res) => {
    data_service.updateDepartment(req.body).then((data) => {
        res.redirect("/departments");
    });
});
app.get("/employee/delete/:empNum", (req, res) => {
    data_service.deleteEmployeeByNum(req.params.empNum).then((data) => {
        res.redirect("/employees");
    }).catch((err) => {
        res.status(500).send("Unable to Remove Employee / Employee not found");
    });
});

app.use((req, res) => {
    res.status(404).send("Page Not Found!");
});

app.listen(HTTP_PORT, onHttpStart);