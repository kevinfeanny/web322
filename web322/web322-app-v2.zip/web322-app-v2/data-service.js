var employee = {};
var departments = [];
var fs = require("fs");

module.exports.initialize = function() {
return new Promise(function(resolve, reject){
    try{
        fs.readFile('./data/employees.json',  function(err, data){
            if (err) throw err;
            employee = JSON.parse(data);

        });
        fs.readFile("./data/departments.json", function(err, data){
            if(err) throw err;
            departments = JSON.parse(data);  
        });
    } catch (ex) {
        reject("Read File Error!");
    }
    resolve("JSON file succesfully read.");

});
}
module.exports.getAllEmployees = function() {
var allEmployees = [];
return new Promise(function(resolve, reject) {
    for (var i = 0; i < employee.length; i++) {
        allEmployees.push(employee[i]);
    }
    if (allEmployees.length == 0) {
        reject("No data");
    }
    resolve(allEmployees);
})
}
module.exports.getManagers = function() {
    var manager = [];
    return new Promise(function(resolve, reject) {
        if (employee.length == 0) {
            reject("No Data");
        } else {
            for (var q = 0; q < employee.length; q++) {
                if (employee[q].isManager == true) {
                    manager.push(employee[q]);
                }
            }
            if (manager.length == 0) {
                reject("No Data");
            }
        }
        resolve(manager);
    });
    }
    
    module.exports.getDepartments = function() {
        var department = [];
        return new Promise(function(resolve, reject) {
            if (employee.length == 0) {
                reject("No Data");
            } else {
                for (var v = 0; v < departments.length; v++) {
                    department.push(departments[v]);
                }
                if (department.length == 0) {
                    reject("No Data");
                }
            }
            resolve(department);
        });
        }