/************************************************************************
*********
*  WEB
3
22 
–
Assignment
1
*  I declare that this assignment is my own work in accordance with Seneca  Academic Polic
y.  
*  No part of this 
assignment has been copied manually or electronically from any other sour
ce
*  (including web sites) or 
distributed to other students.
* 
*  Name: _kevin feanny_____________________ Student ID: __045050036____________ Date: ___1/24/2018_____________
*
*  Online 
(Heroku) 
URL
: https://peaceful-reef-46573.herokuapp.com________________
____________________
___________________
*
********************************************************************************/ 
var HTTP_PORT = process.env.PORT || 8080;
var express = require("express");
var app = express();

// setup a 'route' to listen on the default url path
app.get("/", (req, res) => {
    res.send("Kevin Feanny 045050036");
});

// setup http server to listen on HTTP_PORT
app.listen(HTTP_PORT);