/************************************************************************
*********
*  WEB
3
22 
–
Assignment
02
*  I declare t
hat this assignment is my own work in accordance with Se
neca  Academic Policy.  No part 
*  of this 
assignment has been copied manually or electronically from any other s
ource 
*  (including 3rd party web sites) or 
distributed to other students.
* 
*  Name:
_______Kevin Feanny_______________ Student ID: _______045050036_______ Date: ____8th feb 2018____________
*
*  Online (Heroku) Link: ___https://mighty-waters-69448.herokuapp.com_____________________________________________________
*
********************************************************************************/ 

var express = require("express");
var app = express();
var path = require("path");
const multer = require("multer");
var fs = require("fs");
const bodyParser = require('body-parser');
var data_service = require("./data-service.js");

var HTTP_PORT = process.env.PORT || 8080;

function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);

}
app.use(bodyParser.urlencoded({ extended: true }));
const storage = multer.diskStorage({
    destination: "./public/images/uploaded",
    filename: function (req, file, cb) {
      // we write the filename as the current date down to the millisecond
      // in a large web service this would possibly cause a problem if two people
      // uploaded an image at the exact same time. A better way would be to use GUID's for filenames.
      // this is a simple example.
      cb(null, Date.now() + path.extname(file.originalname));
    }
  });
  
  // tell multer to use the diskStorage function for naming files instead of the default.
  const upload = multer({ storage: storage });
app.use(express.static('public'));

app.get("/", function(req, res) {
    res.sendFile(path.join(__dirname + "/views/home.html"));
});

app.get("/about", function(req, res) {
    res.sendFile(path.join(__dirname + "/views/about.html"));
});

app.get("/employees", function(req, res) {

    if (req.query.status) {
        data_service.getEmployeesByStatus(req.query.status).then(function(data) {
            res.json(data);
        }).catch(function(err) {
            res.json({ message: err });
        });
    } else if (req.query.department) {
        data_service.getEmployeesByDepartment(req.query.department).then(function(data) {
            res.json(data);
        }).catch(function(err) {
            res.json({ message: err });
        });
    } else if (req.query.manager) {
        data_service.getEmployeesByManager(req.query.manager).then(function(data) {
            res.json(data);
        }).catch(function(err) {
            res.json({ message: err });
        });
    } else {
        data_service.getAllEmployees().then(function(data) {
            res.json(data);
        }).catch(function(err) {
            res.json({ message: err });
        });
    }
});


app.get("/employees/:num", function(req, res) {
    data_service.getEmployeeByNum(req.params.num).then(function(data) {
        res.json(data);
    }).catch(function(err) {
        res.json({ message: err });
    });
});





app.get("/managers", function(req, res) {
    data_service.getManagers().then(function(data) {
        res.json(data);
    }).catch(function(err) {
        res.json({ message: err });
    });
});

app.get("/departments", function(req, res) {
    data_service.getDepartments().then(function(data) {
        res.json(data);
    }).catch(function(err) {
        res.json({ message: err });
    });
});

app.get("/images/add", function(req, res){
    res.sendFile(path.join(__dirname + "/views/addimage.html"));
});
app.post("/images/add", upload.single("imageFile"), function(req, res) {
    if (req.file) {
        console.dir(req.file);
        return res.end('Thank you for the file');
      }
  }); 
  app.get("/Images", function(req, res){
    var path = __dirname + "/public/images/uploaded";
 
    fs.readdir(path, function(err, items) {
        res.json(items);
     
      
    });

  });
  app.get("/employee/add", function(req, res){
    res.sendFile(path.join(__dirname + "/views/addEmployee.html"));
});
app.post("/employee/add", (req, res) => {
    console.log(req.body);
    data_service.addEmployee(req.body)
    .then(() => {
        res.redirect("/employees");
    })
    .catch((reason) => {
        res.send("{Error: " + reason + "}");
    });
});



app.use(function(req, res) {
    res.status(404).send("Page Not Found.");
});
data_service.initialize() .then(() =>{
    app.listen(HTTP_PORT, onHttpStart);
}).catch((err) =>{
    console.log("Unable to connect to start server");
});